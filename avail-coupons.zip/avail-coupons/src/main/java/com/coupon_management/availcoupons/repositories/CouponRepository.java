package com.coupon_management.availcoupons.repositories;

import com.coupon_management.availcoupons.Models.Coupon;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CouponRepository extends JpaRepository<Coupon, Long> {
}