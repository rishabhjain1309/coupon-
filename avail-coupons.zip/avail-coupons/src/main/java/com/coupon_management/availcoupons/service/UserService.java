package com.coupon_management.availcoupons.service;

import com.coupon_management.availcoupons.Models.User;
import com.coupon_management.availcoupons.exceptionHandleing.UserNotFoundException;
import com.coupon_management.availcoupons.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService{


    private UserRepository userRepository;

    @Autowired
    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public String createUser(User user) {
        userRepository.save(user);
        return "User created";
    }

    public User getUser(Long id){
        return userRepository.findById(id).orElseThrow(() -> new UserNotFoundException("User not found with this ID: " + id));
    }

}
