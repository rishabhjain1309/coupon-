package com.coupon_management.availcoupons.service;
import com.coupon_management.availcoupons.Models.Product;
import com.coupon_management.availcoupons.Models.User;
import com.coupon_management.availcoupons.exceptionHandleing.ProductNotFoundException;
import com.coupon_management.availcoupons.repositories.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class ProductService {

    @Autowired
    private ProductRepository productRepository;

    public ProductService(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    public String createProduct(Product product) {
        productRepository.save(product);
        return "product created";
    }

    public Product getProductById(Long id) {
       return productRepository.findById(id).get();

    }

    public List<Product> getAll() {

        return productRepository.findAll();
    }

    public void deleteProductById(Long id) throws ProductNotFoundException {
        if (!productRepository.existsById(id)) {
            throw new ProductNotFoundException("Product not found with this ID: " + id);
        }
        productRepository.deleteById(id);
    }
}


