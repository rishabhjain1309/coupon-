package com.coupon_management.availcoupons.exceptionHandleing;

public class ProductNotFoundException extends RuntimeException {
    public ProductNotFoundException(String message) {
        super(message);
    }
}