package com.coupon_management.availcoupons.Models;

import org.antlr.v4.runtime.misc.Pair;

import java.util.ArrayList;
import java.util.List;

public class Cart {
    List<Pair<Product,Integer>> products;
    Integer totalCartValue;
    Integer discountedCartValue;
    User user;
    Coupon coupon;

    Cart(User user)
    {
        products=new ArrayList<>();
        this.user=user;
    }

    public void addProduct(Product product)

}
