package com.coupon_management.availcoupons.exceptionHandleing;

public class UserNotFoundException extends RuntimeException{
    public UserNotFoundException(String message) {
        super(message);
    }
}
