package com.coupon_management.availcoupons.service;

import com.coupon_management.availcoupons.Models.Coupon;
import com.coupon_management.availcoupons.exceptionHandleing.CouponNotFoundException;
import com.coupon_management.availcoupons.repositories.CouponRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class CouponService {

    private CouponRepository couponRepository;

    @Autowired
    public CouponService(CouponRepository couponRepository) {
        this.couponRepository = couponRepository;
    }

    public String createCoupon(Coupon coupon){
        couponRepository.save(coupon);
        return "coupon created";
    }

    public Coupon getCoupon(Long id){
        return couponRepository.findById(id).get();
    }

    public List<Coupon> getAllCoupon() {

        return couponRepository.findAll();
    }

    public void deleteCouponById(Long id) throws CouponNotFoundException {
        if (!couponRepository.existsById(id)) {
            throw new CouponNotFoundException("Coupon not found with this ID: " + id);
        }
        couponRepository.deleteById(id);
    }

//    public double applyCoupon(double totalPrice, Coupon coupon) {
//        // Apply discount logic here
//        return totalPrice - (totalPrice * (coupon.getDiscount() / 100));
//    }
}

