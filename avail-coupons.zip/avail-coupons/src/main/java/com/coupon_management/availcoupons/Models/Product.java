package com.coupon_management.availcoupons.Models;
import jakarta.annotation.sql.DataSourceDefinition;
import jakarta.annotation.sql.DataSourceDefinitions;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@Entity
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Product {

    @Id
    private Long productId;
    private  String name;
    private double productValue;

//    public Product() {
//    }
//
//    public Product(int productId, int name, double productValue) {
//        this.productId = productId;
//        this.name = name;
//        this.productValue = productValue;
//    }
//
//    public int getname() {
//        return name;
//    }
//
//    public void setname(int name) {
//        this.name = name;
//    }
//
//    public int getProductId() {
//        return productId;
//    }
//
//    public void setProductId(int productId) {
//        this.productId = productId;
//    }
//
//    public double getProductValue() {
//        return productValue;
//    }
//
//    public void setProductValue(double productValue) {
//        this.productValue = productValue;
//    }
}