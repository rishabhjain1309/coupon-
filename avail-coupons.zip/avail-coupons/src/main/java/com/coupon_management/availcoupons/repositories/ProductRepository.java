package com.coupon_management.availcoupons.repositories;

import com.coupon_management.availcoupons.Models.Product;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductRepository extends JpaRepository<Product, Long> {

}
