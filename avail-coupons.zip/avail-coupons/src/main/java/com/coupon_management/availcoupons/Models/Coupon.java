package com.coupon_management.availcoupons.Models;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jdk.jfr.Timestamp;

import java.sql.Time;
import java.util.Date;

import static jakarta.persistence.GenerationType.IDENTITY;

@Entity
public class Coupon {

    @Id
    @GeneratedValue(strategy = IDENTITY)
    private Long id;
    private String code;
    private double discount;

//    @Timestamp
//
//    Timestamp expiryDate = new Timestamp;
//    expiryDate.before();
//    Timestamp ActivationDate= new Timestamp.after();
//
//    private double maxDiscount;
//    private double minCartValue;

    public Coupon() {     // default constructor
    }

    public Coupon(String code, double discount) {      // constructor
        this.code = code;
        this.discount = discount;
    }

    public double getDiscount() {
        return discount;
    }

    public void setDiscount(double discount) {
        this.discount = discount;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}


