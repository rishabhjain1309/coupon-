package com.coupon_management.availcoupons.Controllers;

import com.coupon_management.availcoupons.Models.Product;
import com.coupon_management.availcoupons.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/Product")

public class ProductController {

    @Autowired
    ProductService productService;

    ProductController(ProductService productService)
    {
        this.productService = productService;
    }

    @PostMapping
    public String createproduct(@RequestBody Product product) {
        productService.createProduct(product);
        return "Product Created Successfully";
    }

//    @GetMapping("{id}")
//    public Product getUserById(@PathVariable Long id) {
//        return productService.getProductById(id);
//    }

    @GetMapping("/{id}")
    public Product getProductById(@PathVariable Long id){
        return productService.getProductById(id);
    }
    @GetMapping("/getAll")

    public List<Product> getAll(){
        return productService.getAll();
    }


    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteProductById(@PathVariable Long id) {
        productService.deleteProductById(id);
        return ResponseEntity.noContent().build();
    }


}
