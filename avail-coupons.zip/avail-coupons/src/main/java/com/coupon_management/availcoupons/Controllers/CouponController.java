package com.coupon_management.availcoupons.Controllers;

import com.coupon_management.availcoupons.Models.Coupon;
import com.coupon_management.availcoupons.service.CouponService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.w3c.dom.stylesheets.LinkStyle;

import java.util.List;


@RestController
@RequestMapping("/coupons")
public class CouponController {
    private final CouponService couponService;

    CouponController(CouponService couponService){
        this.couponService = couponService;
    }

    @PostMapping
    public String createCouponDetails(@RequestBody Coupon coupon){
        couponService.createCoupon(coupon);
        return "Coupon created successfully";
    }

    @GetMapping("/{id}")
    public Coupon getCouponDetails(@PathVariable("id") Long id){
       return couponService.getCoupon(id);
    }

    @GetMapping("/getAll")
    public List<Coupon> getAllCoupon(){
        return couponService.getAllCoupon();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCouponById(@PathVariable("id") Long id) {
        couponService.deleteCouponById(id);
        return ResponseEntity.noContent().build();
    }


}

