package com.coupon_management.availcoupons.exceptionHandleing;

public class CouponNotFoundException extends RuntimeException {
    public CouponNotFoundException(String message) {
        super(message);
    }
}
