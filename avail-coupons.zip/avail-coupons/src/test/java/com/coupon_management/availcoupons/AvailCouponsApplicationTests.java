package com.coupon_management.availcoupons;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AvailCouponsApplicationTests {

	@Test
	void contextLoads() {
	}

}
